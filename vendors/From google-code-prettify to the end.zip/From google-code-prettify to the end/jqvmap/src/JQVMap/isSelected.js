JQVMap.prototype.isSelected = function(cc) {
  return this.selectIndex(cc) >= 0;
};
