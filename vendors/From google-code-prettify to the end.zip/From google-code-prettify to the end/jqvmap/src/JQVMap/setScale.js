JQVMap.prototype.setScale = function (scale) {
  this.scale = scale;
  this.applyTransform();
};
